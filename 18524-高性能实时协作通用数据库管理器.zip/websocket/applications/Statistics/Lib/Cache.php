<?php
namespace Statistics\Lib;
class Cache
{
    public static $statisticDataCache = array();
    public static $ServerIpList = array();
    public static $modulesDataCache = array();
    public static $lastFailedIpArray = array();
    public static $lastSuccessIpArray = array();
}